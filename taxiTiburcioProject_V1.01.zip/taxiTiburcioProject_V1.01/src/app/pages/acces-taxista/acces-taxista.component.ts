import { Component } from '@angular/core';

@Component({
  selector: 'app-acces-taxista',
  templateUrl: './acces-taxista.component.html',
  styleUrls: ['./acces-taxista.component.scss']
})
export class AccesTaxistaComponent {

}
