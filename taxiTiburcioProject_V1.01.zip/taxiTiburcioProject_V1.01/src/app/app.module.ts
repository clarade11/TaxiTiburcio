import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormularioReservaComponent } from './pages/formulario-reserva/formulario-reserva.component';
import { ApiWhatsappComponent } from './components/api-whatsapp/api-whatsapp.component';
import { HomeComponent } from './pages/home/home.component';
import { InformacionRutasComponent } from './pages/informacion-rutas/informacion-rutas.component';
import { ContactoComponent } from './pages/contacto/contacto.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { ConnectionBBDDComponent } from './components/connection-bbdd/connection-bbdd.component';
import { ErrorComponent } from './pages/error/error.component';
import { AccesTaxistaComponent } from './pages/acces-taxista/acces-taxista.component';
import { BlueHoverDirective } from './directives/blue-hover.directive';
import { DoubleSizeHoverDirective } from './directives/double-size-hover.directive';

@NgModule({
  declarations: [
    AppComponent,
    FormularioReservaComponent,
    ApiWhatsappComponent,
    HomeComponent,
    InformacionRutasComponent,
    ContactoComponent,
    FooterComponent,
    HeaderComponent,
    ConnectionBBDDComponent,
    ErrorComponent,
    AccesTaxistaComponent,
    DoubleSizeHoverDirective,
    BlueHoverDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
