

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const accesoSchema = new Schema({
    USER: String,
    PASSWORD: String,
    VALIDO: String
}, { collection: 'ACCESO' });

module.exports = mongoose.model('ACCESO', accesoSchema);
