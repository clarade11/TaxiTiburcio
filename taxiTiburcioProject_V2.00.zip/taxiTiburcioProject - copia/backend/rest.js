const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const router = express.Router();
const ACCESO = require('./modelos/ACCESO'); // Importa el modelo

const app = express();
mongoose.connect("mongodb://localhost:27017/TaxiTiburcio")    
    .then(() => {
        console.log('Connected to MongoDB')
    })
    .catch(() => {
        console.log('Error connecting to MongoDB');
    })

app.use(bodyParser.json());
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    next();
})

app.get('/ACCESO', (req, res, next) => {
    ACCESO.find()
    .then((data) => {
        res.json({'ACCESO': data});
    })
    .catch(() => {
        console.log('Error fetching entries')
    })
;
  });

module.exports = app;