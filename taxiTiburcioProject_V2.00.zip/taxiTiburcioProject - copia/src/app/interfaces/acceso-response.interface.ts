import { Acceso } from "./acceso.interface";

export interface AccesoResponse{
    results:Acceso[];
}