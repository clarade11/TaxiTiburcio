import { Component } from '@angular/core';

@Component({
  selector: 'app-informacion-rutas',
  templateUrl: './informacion-rutas.component.html',
  styleUrls: ['./informacion-rutas.component.scss']
})
export class InformacionRutasComponent {

}
