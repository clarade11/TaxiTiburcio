import { Component , OnInit} from '@angular/core';
import { AccesoResponse } from 'src/app/interfaces/acceso-response.interface';
import { Acceso } from 'src/app/interfaces/acceso.interface';
import { AccesoService } from 'src/app/services/accesoService.service';


@Component({
  selector: 'app-acces-taxista',
  templateUrl: './acces-taxista.component.html',
  styleUrls: ['./acces-taxista.component.scss']
})
export class AccesTaxistaComponent implements OnInit {
  constructor(private accesoServicio:AccesoService) { 
  }
  
  ngOnInit(): void {

    this.accesoServicio.obtenerUsuarios().subscribe({
      next:(resp : AccesoResponse) => {
        this.accesos = resp.results
        console.log(this.accesos)
      },
      error: (err) => {
        console.log('Ha ocurrido un error en la consulta')
      }
    });
    console.log(this.accesoServicio.obtenerUsuarios());
  }

  public accesos : Acceso[]=[];

  public error=false

  public messError = '';

  public messSesion = '';

  public loginSesion = false

  public user = {
    email:'',
    password:''
  }

 

  public login(){
    this.validateUser
    if(this.error){
      this.loginSesion=true;
    }else{
      this.loginSesion=false;
    }

    if(!this.loginSesion){
      this.messSesion='Sesión iniciada por: '+this.user.email+' con contraseña: '+this.user.password;
      this.messError=''
    }
  }

  public validateUser(){
    let passErr=false;
    let emaErr=false;
    //validate password
   // if(this.user.password.length < 8){
    //  passErr=true
    //}else{
     // passErr=false
   // }

    //validate email
  //  if(this.user.email.includes('@gmail.com') || this.user.email.includes('@hotmail.com')){
    //  emaErr=false
  //  }else{
    //  emaErr=true
  //  }
    //if errorLocal exists -> error=true
    console.info('Email : '+this.user.email );
    console.log('Password : '+this.user.password );
    if(passErr || emaErr){
      this.error=true;
      this.messError=''
      if(passErr){
        this.messError += 'La contraseña debe tener una longitud de más de 8 carácteres. '
      }
      if(emaErr){
        this.messError +='El email no es correcto. '
      }
    }

  }

}
function ngOnInit() {
  throw new Error('Function not implemented.');
}

