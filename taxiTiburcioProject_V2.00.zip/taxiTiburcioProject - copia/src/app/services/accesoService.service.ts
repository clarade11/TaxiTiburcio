import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, map } from 'rxjs';
import { AccesoResponse } from '../interfaces/acceso-response.interface';
import { ObjectId } from 'mongoose';
import { Acceso } from '../interfaces/acceso.interface';

@Injectable({
  providedIn: 'root'
})
export class AccesoService {

  constructor(private http: HttpClient) {}

  public accesoSubject = new Subject<Acceso[]>();
  private accesos: Acceso[] = [];

  public obtenerUsuarios(): Observable<AccesoResponse> {
    return this.http.get<AccesoResponse>('http://localhost:3000/ACCESO')
  }

  // Otras funciones para crear, actualizar y eliminar elementos
}