import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WhatsappService {

  private datos: any[];

  constructor() {
    this.datos = [];
  }

  // Métodos y funcionalidades del servicio

  agregarDato(dato: any): void {
    this.datos.push(dato);
  }

  obtenerDatos(): any[] {
    return this.datos;
  }
}
