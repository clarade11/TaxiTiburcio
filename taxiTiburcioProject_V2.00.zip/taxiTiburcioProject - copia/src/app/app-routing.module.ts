import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { FormularioReservaComponent } from './pages/formulario-reserva/formulario-reserva.component';
import { ContactoComponent } from './pages/contacto/contacto.component';
import { InformacionRutasComponent } from './pages/informacion-rutas/informacion-rutas.component';
import { ErrorComponent } from './pages/error/error.component';
import { AccesTaxistaComponent } from './pages/acces-taxista/acces-taxista.component';

const routes: Routes = [
  {
    path:'', component: HomeComponent
  },
  {
    path:'reserva', component: FormularioReservaComponent
  },
  {
    path:'contacto', component: ContactoComponent
  },
  {
    path:'informacion', component: InformacionRutasComponent
  },
  {
    path: 'error-404', component:ErrorComponent
  },
  {
    path: 'taxista', component:AccesTaxistaComponent
  },
  {
    path: '**', pathMatch:'full' , redirectTo: 'error-404'/*Cuando pongamos cualquier ruta que no coincide, te lleva directo a error */
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
