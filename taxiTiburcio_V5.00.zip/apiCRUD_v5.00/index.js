const express = require('express')
const mysql = require('mysql')
const cors = require('cors');
const bodyParser = require('body-parser')

const app = express()

app.use(cors())

app.use(function(req,res,next) {
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Methods', '*')
    next()
})

app.use(bodyParser.json())



const PUERTO=3000

const conexion = mysql.createConnection(
    {
        host:'localhost',
        database:'taxitiburcio',
        user:'root',
        password:''
    }
)

app.listen(PUERTO, ()=>{
    console.log('Servidor corriendo ')
})

conexion.connect(error=>{
    if(error) throw error
    console.log('Conexion exitosa a la base de datos')
})

app.get('/', (req, res)=>{
    res.send('API')
})

//////////////////////ACCESO////////////////////////////

app.get('/acceso', (req, res)=>{
    const query = 'SELECT * FROM acceso'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/acceso/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM acceso WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/acceso/buscar/:user',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {user} = req.params
    const query = `SELECT password FROM acceso WHERE USER='${user}' and vigente='S' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el user indicado')
        }
    })
})

app.post('/acceso/agregar',(req, res) => {
    const acceso ={
        nombre:req.body.nombre,
        email:req.body.email,
        vigente:req.body.vigente,
        f_modifica:null
    }
    const query = `INSERT INTO acceso SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})

app.put('/acceso/actualizar/:id',(req, res) => {
    const {id} = req.params

    const {user, password, vigente, f_creacion} = req.body

    const query = `UPDATE acceso SET user =${user}, password=${password}, vigente=${vigente}, f_creacion=${f_creacion} WHERE id=${id}`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se actualizó correctamente el registro')
       
    })
})


app.delete('/acceso/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM acceso WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})


//////////////////////ANDALUCIA_CONECTA////////////////////////////

app.get('/andalucia_conecta', (req, res)=>{
    const query = 'SELECT * FROM andalucia_conecta'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/andalucia_conecta/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM andalucia_conecta WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/andalucia_conecta/buscar/:ciudad_recogida',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {ciudad_recogida} = req.params
    const query = `SELECT * FROM andalucia_conecta WHERE ciudad_recogida='${ciudad_recogida}' and vigente='S' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con la ciudad_recogida indicado')
        }
    })
})

app.post('/andalucia_conecta/agregar',(req, res) => {
    const acceso ={
        ciudad_recogida:req.body.ciudad_recogida,
        hora_salida:req.body.hora_salida,
        telefono_informacion:req.body.telefono_informacion,
        precio:req.body.precio,
        num_plazas:req.body.num_plazas,
        vigente:req.body.vigente,
        f_modifica:null
    }
    const query = `INSERT INTO andalucia_conecta SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})

app.put('/andalucia_conecta/actualizar/:id',(req, res) => {
    const {id} = req.params

    const {ciudad_recogida, hora_salida, 
        telefono_informacion,precio, num_plazas,vigente,  f_creacion} = req.body

    const query = `UPDATE andalucia_conecta SET ciudad_recogida =${ciudad_recogida}
    , hora_salida=${hora_salida}, telefono_informacion=${telefono_informacion}, precio=${precio}
    , num_plazas=${num_plazas} , vigente=${vigente},  f_creacion=${ f_creacion} WHERE id=${id}`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se actualizó correctamente el registro')
       
    })
})


app.delete('/andalucia_conecta/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM andalucia_conecta WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})


//////////////////////ASKS////////////////////////////

app.get('/asks', (req, res)=>{
    const query = 'SELECT id,ask, answer, nombre_contacto, telefono_contacto,vigente FROM asks'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/asksRespondidas', (req, res)=>{
    const query = 'SELECT ask, answer FROM asks where VIGENTE="S" and ANSWER is not null '
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
            console.log('No hay resgistros')
        }
    })
})

app.put('/asks/actualizar/:id', (req, res) => {
    const { id } = req.params;
    const { answer } = req.body;
      
    const query = `UPDATE asks SET answer = ? WHERE id = ?`;
    const params = [answer, id];
    
    console.log('ID de la pregunta a actualizar:', id);
    console.log('Nueva respuesta:', answer);
    
    conexion.query(query, params, (error, resultado) => {
      if (error) {
        console.error('Error al actualizar la pregunta:', error.message);
        res.status(500).json({ error: 'Error al actualizar la respuesta' });
      } else {
        console.log('Registro actualizado correctamente');
        res.json('Se actualizó correctamente el registro');
      }
    });
});

app.put('/asks/actualizarVigencia/:id', (req, res) => {
    const { id } = req.params;
    const { vigente } = req.body;
      
    const query = `UPDATE asks SET vigente = ? WHERE id = ?`;
    const params = [vigente, id];
    
    console.log('ID de la pregunta a actualizar:', id);
    console.log('Nueva vigencia:', vigente);
    
    conexion.query(query, params, (error, resultado) => {
      if (error) {
        console.error('Error al actualizar la pregunta:', error.message);
        res.status(500).json({ error: 'Error al actualizar la respuesta' });
      } else {
        console.log('Registro actualizado correctamente');
        res.json('Se actualizó correctamente el registro');
      }
    });
});


app.get('/asksNoRespondidas', (req, res)=>{
    const query = 'SELECT id,ask, nombre_contacto, telefono_contacto FROM asks where ANSWER is null '
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
            console.log('No hay resgistros')
        }
    })
})

app.get('/asks/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM asks WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/asks/buscar/:ask',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {ask} = req.params
    const query = `SELECT * FROM asks WHERE ask='${ask}' and vigente='S' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con la ask indicado')
        }
    })
})

app.post('/asks/agregar',(req, res) => {
    const acceso ={
        ask:req.body.ask,
        answer:null,
        vigente:"N",
        f_modifica:null,
        telefono_contacto:req.body.telefono_contacto,
        nombre_contacto:req.body.nombre_contacto
    }
    const query = `INSERT INTO asks SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})



app.delete('/asks/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM asks WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})


//////////////////////CONSTANTES////////////////////////////

app.get('/constantes', (req, res)=>{
    const query = 'SELECT * FROM constantes'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/constantes/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM constantes WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/constantes/buscar/:codigo',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {codigo} = req.params
    const query = `SELECT * FROM constantes WHERE codigo='${codigo}' and vigente='S' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con la ask indicado')
        }
    })
})

app.post('/constantes/agregar',(req, res) => {
    const acceso ={
        codigo:req.body.codigo,
        valor:req.body.valor,
        observaciones:req.body.observaciones,
        vigente:req.body.vigente,
        f_modifica:null
    }
    const query = `INSERT INTO constantes SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})

app.put('/constantes/actualizar/:id',(req, res) => {
    const {id} = req.params

    const {codigo, valor,observaciones,vigente,  f_creacion} = req.body

    const query = `UPDATE constantes SET codigo =${codigo}
    , valor=${valor}, observaciones=${observaciones} , vigente=${vigente},  f_creacion=${ f_creacion} WHERE id=${id}`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se actualizó correctamente el registro')
       
    })
})


app.delete('/constantes/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM constantes WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})



//////////////////////HOME////////////////////////////

app.get('/home', (req, res)=>{
    const query = 'SELECT * FROM home'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/home/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM home WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/home/buscar/:photo',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {photo} = req.params
    const query = `SELECT * FROM home WHERE photo='${photo}' and vigente='S' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el parametro indicado')
        }
    })
})

app.post('/home/agregar',(req, res) => {
    const acceso ={
        photo:req.body.photo,
        description:req.body.description,
        vigente:req.body.vigente,
        f_modifica:null
    }
    const query = `INSERT INTO home SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})

app.put('/home/actualizar/:id',(req, res) => {
    const {id} = req.params

    const {photo, description,vigente,  f_creacion} = req.body

    const query = `UPDATE home SET photo =${photo}
    , description=${description}, vigente=${vigente},  f_creacion=${ f_creacion} WHERE id=${id}`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se actualizó correctamente el registro')
       
    })
})


app.delete('/home/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM home WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})

//////////////////////RESERVAS////////////////////////////

app.get('/reservas', (req, res)=>{
    const query = 'SELECT id,telefono, calle_recogida, ciudad_recogida, cod_postal, cod_postal, finalizado, hora_viaje, fecha_viaje, nombre, num_personas, telefono, sillita FROM reservas WHERE FINALIZADO="N"'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/reservasDias', (req, res)=>{
    const query = 'SELECT FECHA_VIAJE FROM reservas WHERE FINALIZADO="N"'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/reservas/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM reservas WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/reservas/buscar/:telefono',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {telefono} = req.params
    const query = `SELECT * FROM reservas WHERE telefono='${telefono}' and finalizado='N' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con la telefono indicado')
        }
    })
})

app.post('/reservas/agregar',(req, res) => {
    const acceso ={
        telefono:req.body.telefono,
        nombre:req.body.nombre,
        ciudad_recogida:req.body.ciudad_recogida,
        cod_postal:req.body.cod_postal,
        calle_recogida:req.body.calle_recogida,
        fecha_viaje:req.body.fecha_viaje,
        hora_viaje:req.body.hora_viaje,
        sillita:req.body.sillita,
        num_personas:req.body.num_personas,
        finalizado:req.body.finalizado,
        f_modifica:null
    }
    const query = `INSERT INTO reservas SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})

app.put('/reservas/actualizar/:id',(req, res) => {
    const {id} = req.params

    const {telefono, nombre, 
        ciudad_recogida,cod_postal, calle_recogida,fecha_viaje,hora_viaje,sillita, num_personas ,finalizado,  f_creacion} = req.body

    const query = `UPDATE reservas SET telefono =${telefono}
    , nombre=${nombre}, ciudad_recogida=${ciudad_recogida}, cod_postal=${cod_postal}
    , calle_recogida=${calle_recogida} , fecha_viaje=${fecha_viaje} , hora_viaje=${hora_viaje} , sillita=${sillita} , num_personas=${num_personas} , finalizado=${finalizado},  f_creacion=${ f_creacion}
    WHERE id=${id}`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se actualizó correctamente el registro')
       
    })
})

app.get('/reservas/finalizarReserva/:id', (req, res) => {
    const { id } = req.params;
    const query = `UPDATE reservas SET finalizado='S' WHERE id=${id}`;
    conexion.query(query, (error, resultado) => {
        if (error) return console.error(error.message);
        res.json('Se finalizó correctamente la reserva');
    });
});


app.delete('/reservas/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM reservas WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})

//////////////////////RUTAS////////////////////////////

app.get('/rutas', (req, res)=>{
    const query = 'SELECT id, imagen, destino,ciudad_recogida, cod_postal, calle_recogida  FROM rutas where vigente="S"'
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistros')
        }
    })
})

app.get('/rutas/:id',(req, res) => {
    const {id} = req.params
    const query = `SELECT * FROM rutas WHERE id=${id}`
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el id indicado')
        }
    })
})

app.get('/rutas/buscar/:destino',(req, res) => { //recogemos el registro del usuario activo para iniciar sesion
    const {destino} = req.params
    const query = `SELECT * FROM rutas WHERE destino='${destino}' and vigente='S' `
    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)

        if(resultado.length > 0){
            res.json(resultado)
        }else{
            res.json('No hay resgistro con el destino indicado')
        }
    })
})

app.post('/rutas/agregar',(req, res) => {
    const acceso ={
        ciudad_recogida:req.body.ciudad_recogida,
        imagen:req.body.imagen,
        destino:req.body.destino,
        cod_postal:req.body.cod_postal,
        calle_recogida:req.body.calle_recogida,
        precio:req.body.precio,
        vigente:req.body.vigente,
        f_modifica:null
    }
    const query = `INSERT INTO rutas SET ?`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)

        res.json('Se insertó correctamente el registro')
       
    })
})

app.put('/rutas/actualizar/:id',(req, res) => {
    const {id} = req.params

    const {ciudad_recogida,destino, cod_postal,calle_recogida,precio ,vigente,  f_creacion} = req.body

    const query = `UPDATE rutas SET ciudad_recogida=${ciudad_recogida},imagen=${imagen},
    , destino=${destino} , cod_postal=${cod_postal} , calle_recogida=${calle_recogida} 
    , precio=${precio}, vigente=${vigente},  f_creacion=${ f_creacion}
    WHERE id=${id}`
    conexion.query(query, acceso, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se actualizó correctamente el registro')
       
    })
})


app.delete('/rutas/borrar/:id',(req, res) => {
    const {id} = req.params

    const query = `DELETE FROM rutas WHERE id=${id}`

    conexion.query(query, (error, resultado)=>{
        if(error) return console.error(error.message)
      
        res.json('Se eliminó correctamente el registro')
       
    })
})