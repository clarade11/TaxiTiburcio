import { Time } from "@angular/common";

export class ReservasModel{
  constructor(
    public id: number,
    public telefono: number,
    public nombre:string,
    public ciudad_recogida:string,
    public cod_postal:number,
    public calle_recogida:string,
    public fecha_viaje:Date,
    public hora_viaje:number,
    public num_personas:number,
    public sillita:string,
    public finalizado:string,
    public f_modifica:Date
  ){
  }
}
