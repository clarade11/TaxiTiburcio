import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AsksModel } from './asks.model';

@Injectable({
  providedIn: 'root'
})
export class AsksService {

  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerAsks(){
    return this.http.get<AsksModel[]>(this.BASE_URL+'/asks');
  }

  actualizarRespuesta(id: number, respuesta: string) {
    return this.http.put<string>(`${this.BASE_URL}/asks/actualizarRespuesta/${id}`, { respuesta });
  }

  actualizarAskRespuesta(id: number, respuesta: string) {
    return this.http.put<string>(`${this.BASE_URL}/asks/actualizar/${id}`, { answer: respuesta });
  }

  obtenerAsksRespondidas(){
    return this.http.get<AsksModel[]>(this.BASE_URL+'/asksRespondidas');
  }

  obtenerAsksNoRespondidas(){
    return this.http.get<AsksModel[]>(this.BASE_URL+'/asksNoRespondidas');
  }

  obtenerAskPorId(id: number){
    return this.http.get<AsksModel[]>(`${this.BASE_URL}/asks/${id}`);
  }

  obtenerAsk(ask: string){
    return this.http.get<AsksModel[]>(`${this.BASE_URL}/asks/buscar/${ask}`);
  }

  agregarAsk(ask: AsksModel){
    return this.http.post<string>(`${this.BASE_URL}/asks/agregar`,ask);
  }

  actualizarAsk(ask: AsksModel){
    return this.http.put<AsksModel>(`${this.BASE_URL}/asks/actualizar/${ask.id}`,ask);
  }

  actualizarVigencia(ask: AsksModel){
    return this.http.put<AsksModel>(`${this.BASE_URL}/asks/actualizarVigencia/${ask.id}`,ask);
  }

  borrarAsk(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/asks/borrar/${id}`);
  }
}
