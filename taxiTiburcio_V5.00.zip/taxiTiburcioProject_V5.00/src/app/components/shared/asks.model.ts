export class AsksModel{
  constructor(
    public id: number,
    public ask: string,
    public answer:string,
    public vigente:string,
    public telefono_contacto:number,
    public nombre_contacto:string,
    public f_creacion:Date,
    public f_modifica:Date
  ){
  }
}
