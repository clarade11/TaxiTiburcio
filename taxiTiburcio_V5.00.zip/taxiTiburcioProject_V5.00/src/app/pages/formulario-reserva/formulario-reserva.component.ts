import { Component } from '@angular/core';
import { ReservasModel } from 'src/app/components/shared/reservas.model';
import { Observable,of } from 'rxjs';
import { map, catchError  } from 'rxjs/operators';
import { ReservasService } from 'src/app/components/shared/reservas.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-formulario-reserva',
  templateUrl: './formulario-reserva.component.html',
  styleUrls: ['./formulario-reserva.component.scss'],
})
export class FormularioReservaComponent {
  //creacion objeto
  public fechaActual = new Date();
  public diasReservadosString: string = '';
  public diasReservados: Date[] = [];
  public reservados: string[] = [];

  public reserva = {
    dia: this.fechaActual,
    hora_salida: this.fechaActual.getTime(),
    ciudad_recogida: '',
    cod_postal: 0,
    nombre: '',
    sillita: false,
    lugar_encuentro: '',
    num_personas: 0,
    telefono: 0,
    destino: '',
  };

  //BBDD

  reservas: Observable<ReservasModel[]> | undefined;

  constructor(
    private reservasService: ReservasService,
    private route: ActivatedRoute,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      console.log(params['destino'])
      if (params['destino']) {
        this.reserva.destino = params['destino'];
      }
      if (params['ciudadRecogida']) {
        this.reserva.ciudad_recogida = params['ciudadRecogida'];
      }
      console.log(params['ciudadRecogida'])
      if (params['puntoEncuentro']) {
        this.reserva.lugar_encuentro = params['puntoEncuentro'];
      }
      if (params['codigoPostal']) {
        this.reserva.cod_postal = +params['codigoPostal']; // Convertir a número
      }
    });

    console.log('Obteniendo reservas...');
    this.reservas = this.reservasService.obtenerReservasDiasReservados();
    this.reservas.subscribe(reservas => {
      console.log('Reservas obtenidas:', reservas);
    });

    this.reservasService.obtenerReservasDiasReservados().subscribe(reservas => {
      this.diasReservados = reservas.map(reserva => new Date(reserva.fecha_viaje));
      this.diasReservadosString = this.diasReservados.map(date => this.formatDateToString(date)).join(', ');
      this.reservados = this.diasReservadosString.split(',');
    });




  }

  isReservedDate(date: Date): boolean {
    return this.diasReservados.some(reservedDate => this.compareDates(reservedDate, date));
  }

  compareDates(date1: Date, date2: Date): boolean {
    return date1.toDateString() === date2.toDateString();
  }

  formatDateToString(date: Date): string {
    return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
  }

  public reservar(
    dia: Date,
    hora_salida: number,
    ciudad_recogida: string,
    cod_postal: number,
    nombre: string,
    num_personas: number,
    sillita: boolean,
    lugar_encuentro: string,
    telefono: number,
    destino: string
  ) {
    // Validar que los campos obligatorios no estén vacíos
    if (
      !dia ||
      !hora_salida ||
      !ciudad_recogida ||
      !cod_postal ||
      !nombre ||
      !num_personas ||
      !lugar_encuentro ||
      !telefono ||
      !destino
    ) {
      console.error('Error: Todos los campos son obligatorios');
      this.mostrarMensaje('Error: Todos los campos son obligatorios');
      return;
    }

    // Validar que el número de personas sea un número positivo
    if (num_personas <= 0 || num_personas > 7) {
      console.error('Error: El número de personas tiene que ser entre 1 y 6');
      this.mostrarMensaje('Error: El número de personas tiene que ser entre 1 y 6');
      return;
    }

    // Validar que el teléfono sea un número positivo
    if (telefono <= 111111111 || num_personas >999999999) {
      console.error('Error: Se debe introducir un número de teléfono correcto');
      this.mostrarMensaje('Error: Se debe introducir un número de teléfono correcto');
      return;
    }

    let silla = "";
    if(sillita){
      silla="S";
    }else{
      silla="N";
    }


    const nuevaReserva: ReservasModel = {
      id: 0, //al ser autoincremental en el back no se vuelca el 1
      telefono: this.reserva.telefono,
      nombre: this.reserva.nombre,
      ciudad_recogida: this.reserva.ciudad_recogida, // Deberías tener este valor disponible en el backend o en el formulario
      cod_postal: this.reserva.cod_postal, // Aquí puedes establecer un código postal si lo tienes disponible
      calle_recogida: this.reserva.lugar_encuentro, // Deberías tener este valor disponible en el backend o en el formulario
      fecha_viaje:  this.reserva.dia,
      hora_viaje: this.reserva.hora_salida,
      sillita: silla, //pendiente traduccion a string el boolean
      num_personas: this.reserva.num_personas, // Puedes establecer un valor predeterminado o recogerlo del formulario
      finalizado: 'N', // Siempre establecido como 'N' según tu modelo
      f_modifica: new Date(),
    };

    this.reservasService.agregarReserva(nuevaReserva).subscribe(
      () => {
        // Manejar la respuesta si es necesario
        console.log('Reserva agregada correctamente');
        this.mostrarMensaje('Reserva agregada correctamente');
        this.limpiarCampos();
      },
      (error) => {
        console.error('Error al agregar reserva:', error);
      }
    );
  }
  private mostrarMensaje(mensaje: string): void {
    this._snackBar.open(mensaje, 'Cerrar', {
      duration: 5000, // Duración del mensaje en milisegundos (5 segundos en este caso)
    });
  }

  private limpiarCampos(): void {
    this.reserva = {
      dia: this.fechaActual,
      hora_salida: this.fechaActual.getTime(),
      ciudad_recogida: '',
      cod_postal: 0,
      nombre: '',
      sillita: false,
      lugar_encuentro: '',
      num_personas: 0,
      telefono: 0,
      destino: '',
    };
  }

}
