import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AccesoService } from 'src/app/components/shared/accesoService.service';
import { AccesoModel } from 'src/app/components/shared/acceso.model';
import { ReservasModel } from 'src/app/components/shared/reservas.model';
import { ReservasService } from 'src/app/components/shared/reservas.service';
import { DatePipe } from '@angular/common';
import { AsksModel } from 'src/app/components/shared/asks.model';
import { AsksService } from 'src/app/components/shared/asks.service';

@Component({
  selector: 'app-acces-taxista',
  templateUrl: './acces-taxista.component.html',
  styleUrls: ['./acces-taxista.component.scss'],
  providers: [DatePipe]
})
export class AccesTaxistaComponent implements OnInit {
  isLoggedIn: boolean = false;
  accesos: Observable<AccesoModel[]> | undefined;

  asks: Observable<AsksModel[]> | undefined;
  destacarDudas: Observable<AsksModel[]> | undefined;
  askResponse: { [key: number]: string } = {};

  reservas: Observable<ReservasModel[]> | undefined;

  constructor(
    private accesoService: AccesoService,
    private reservasService: ReservasService,
    public datePipe: DatePipe,
    private asksService: AsksService
  ) {}

  ngOnInit(): void {
    this.accesos = this.accesoService.obtenerAccesos();
    this.reservas = this.reservasService.obtenerReservas();
    this.asks = this.asksService.obtenerAsksNoRespondidas();
    this.destacarDudas = this.asksService.obtenerAsks();
  }

  responder(askId: number) {
    const responseText = this.askResponse[askId];
    if (responseText) {
      this.asksService.actualizarAskRespuesta(askId, responseText).subscribe(
        () => {
          console.log('Respuesta enviada para la pregunta con ID', askId);
          this.askResponse[askId] = '';
          this.asks = this.asksService.obtenerAsksNoRespondidas();
          this.destacarDudas = this.asksService.obtenerAsks();
        },
        error => {
          console.error('Error al enviar la respuesta:', error);
        }
      );
    } else {
      console.warn('La respuesta no puede estar vacía');
    }
  }

  cambiarVigencia(ask: AsksModel) {
    const nuevaVigencia = ask.vigente === 'S' ? 'N' : 'S';
    ask.vigente = nuevaVigencia;
    this.asksService.actualizarVigencia(ask).subscribe(
      () => {
        console.log(`Pregunta con ID ${ask.id} actualizada a vigente=${nuevaVigencia}`);
        this.asks = this.asksService.obtenerAsksNoRespondidas();
      },
      error => {
        console.error('Error al actualizar la vigencia de la pregunta:', error);
      }
    );
  }

  cancelarReserva(id: number) {
    if (id && id > 0) {
      console.log('Cancelar reserva con ID:', id);
      this.reservasService.borrarReserva(id).subscribe(
        () => {
          this.reservas = this.reservasService.obtenerReservas();
        },
        error => {
          console.error('Error al cancelar la reserva:', error);
        }
      );
    } else {
      console.warn('ID de reserva no válido:', id);
    }
  }

  finalizarReserva(id: number) {
    if (id && id > 0) {
      console.log('Finalizar reserva con ID:', id);
      this.reservasService.finalizarReservaPorId(id).subscribe(
        () => {
          this.reservas = this.reservasService.obtenerReservas();
        },
        error => {
          console.error('Error al finalizar la reserva:', error);
          if (error.status === 404) {
            this.messError = 'Reserva no encontrada.';
          } else {
            this.messError = 'Error al finalizar la reserva.';
          }
        }
      );
    } else {
      console.warn('ID de reserva no válido:', id);
    }
  }

  public error = false;
  public messError = '';
  public messSesion = '';
  public user = {
    user: '',
    password: ''
  }

  public login(user: string, password: string) {
    this.accesoService.obtenerAccesoUsuarioPassword(user).subscribe(
      (data: AccesoModel[]) => {
        if (data.length > 0 && data[0].password === password) {
          this.isLoggedIn = true;
          this.messSesion = 'Sesión iniciada por: ' + user + ' con contraseña: ' + password;
          this.messError = '';
        } else {
          this.error = true;
          this.messError = 'Usuario o contraseña incorrectos';
        }
      },
      error => {
        console.error('Error al iniciar sesión:', error);
        this.error = true;
        this.messError = 'Error al iniciar sesión';
      }
    );
  }
}
