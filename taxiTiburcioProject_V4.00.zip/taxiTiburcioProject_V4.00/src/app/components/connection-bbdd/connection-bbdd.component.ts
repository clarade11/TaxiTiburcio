import { Component } from '@angular/core';

@Component({
  selector: 'app-connection-bbdd',
  templateUrl: './connection-bbdd.component.html',
  styleUrls: ['./connection-bbdd.component.scss']
})
export class ConnectionBBDDComponent {

}
