import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appDisabledDates]'
})
export class DisabledDatesDirective implements OnInit {
  @Input() appDisabledDates: string[] = [];

  constructor(private el: ElementRef<HTMLInputElement>) {}

  ngOnInit(): void {
    const inputElement = this.el.nativeElement;
    inputElement.addEventListener('input', () => {
      const selectedDate = inputElement.value;
      if (this.appDisabledDates.includes(selectedDate)) {
        inputElement.value = '';
      }
    });
  }
}
