import { Directive ,ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appBlueHover]'
})
export class BlueHoverDirective {

  constructor(
    private elementRef:  ElementRef
    ) { }

  @HostListener('mouseover')
  onMouseOver(){
    this.elementRef.nativeElement.style.color = 'blue';
  }

  @HostListener('mouseout')
  onMouseOut(){
    this.elementRef.nativeElement.style.color = 'white';
  }

}
