import { ObjectId } from "mongoose";

export interface Acceso{
    _id: ObjectId;
    USER: string;
    PASSWORD: string;
    VALIDO: string;
}