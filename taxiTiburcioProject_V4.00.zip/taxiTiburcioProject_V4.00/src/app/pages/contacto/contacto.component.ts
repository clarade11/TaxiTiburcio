import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { AsksModel } from 'src/app/components/shared/asks.model';
import { AsksService } from 'src/app/components/shared/asks.service';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.scss']
})
export class ContactoComponent {


 preguntasRespondidas: Observable<AsksModel[]> | undefined;

 constructor(
   private asksService: AsksService,
   private _snackBar: MatSnackBar
 ) {

 }

 ngOnInit(): void {
  this.preguntasRespondidas = this.asksService.obtenerAsksRespondidas();



}

 public pregunta = {
  telefono: 0,
  nombre: "",
  duda:""
 }
 public errores = {
  telefono: '',
  nombre: '',
  duda: ''
};

 public preguntar(){
  if (this.validarFormulario()) {
    //hay que añadir la columna de telefono y nombre en la tabla de base de datos, añadirlo al modelado y a la api
  const preguntaNueva: AsksModel = {
    id: 0, //al ser autoincremental en el back no se vuelca el 1++
    ask: this.pregunta.duda,
    answer: '',
    vigente: 'S',
    telefono_contacto: this.pregunta.telefono,
    nombre_contacto: this.pregunta.nombre,
    f_creacion: new Date(),
    f_modifica: new Date()
  };

  this.asksService.agregarAsk(preguntaNueva).subscribe(
    () => {
      // Manejar la respuesta si es necesario
      console.log('Pregunta agregada correctamente');
      this.mostrarMensaje('Pregunta agregada correctamente');
    },
    (error) => {
      console.error('Error al agregar la pregunta:', error);
    }
  );
  }
 }
 private mostrarMensaje(mensaje: string): void {
  this._snackBar.open(mensaje, 'Cerrar', {
    duration: 5000, // Duración del mensaje en milisegundos (5 segundos en este caso)
  });
}


private validarFormulario(): boolean {
  let valido = true;

  // Validar que el teléfono sea un número positivo
  if (this.pregunta.telefono <= 111111111 ) {
    this.errores.telefono = 'Por favor, introduce un número de teléfono válido de 9 dígitos';
    this.mostrarMensaje('Error: Se debe introducir un número de teléfono correcto');
    valido = false;
  }else {
    this.errores.telefono = '';
  }

  if (!this.pregunta.nombre || this.pregunta.nombre.trim().length < 3) {
    this.errores.nombre = 'El nombre debe tener al menos 3 caracteres';
    valido = false;
  } else {
    this.errores.nombre = '';
  }

  if (!this.pregunta.duda || this.pregunta.duda.trim().length < 10) {
    this.errores.duda = 'Por favor, introduce una duda de al menos 10 caracteres';
    valido = false;
  } else {
    this.errores.duda = '';
  }

  return valido;
}

logToConsole(value: any) {
  console.log(value);
}
}
