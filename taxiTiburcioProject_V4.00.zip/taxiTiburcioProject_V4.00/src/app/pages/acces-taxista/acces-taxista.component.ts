import { Component , OnInit} from '@angular/core';
import { AccesoService } from 'src/app/components/shared/accesoService.service';
import { Observable } from 'rxjs';
import { AccesoModel } from 'src/app/components/shared/acceso.model';


@Component({
  selector: 'app-acces-taxista',
  templateUrl: './acces-taxista.component.html',
  styleUrls: ['./acces-taxista.component.scss']
})
export class AccesTaxistaComponent implements OnInit {

  //BBDD

  accesos: Observable<AccesoModel[]> | undefined

  constructor(private accesoService:AccesoService){}

  ngOnInit(): void {
    this.accesos = this.accesoService.obtenerAccesos();
  }



  public error=false

  public messError = '';

  public messSesion = '';

  public loginSesion = false

  public user = {
    user:'',
    password:''
  }



  public login(user:string, password:string){

    this.accesoService.obtenerAccesoUsuarioPassword(user).subscribe(data=>{
      console.log(data);
    })




    this.validateUser
    if(this.error){
      this.loginSesion=true;
    }else{
      this.loginSesion=false;
    }

    if(!this.loginSesion){
      this.messSesion='Sesión iniciada por: '+this.user.user+' con contraseña: '+this.user.password;
      this.messError=''
    }
  }

  public validateUser(){
    let passErr=false;
    let emaErr=false;
    //validate password
   // if(this.user.password.length < 8){
    //  passErr=true
    //}else{
     // passErr=false
   // }

    //validate email
  //  if(this.user.email.includes('@gmail.com') || this.user.email.includes('@hotmail.com')){
    //  emaErr=false
  //  }else{
    //  emaErr=true
  //  }
    //if errorLocal exists -> error=true
    console.info('Usuario : '+this.user.user );
    console.log('Password : '+this.user.password );
    if(passErr || emaErr){
      this.error=true;
      this.messError=''
      if(passErr){
        this.messError += 'La contraseña debe tener una longitud de más de 8 carácteres. '
      }
      if(emaErr){
        this.messError +='El email no es correcto. '
      }
    }

  }

}
function ngOnInit() {
  throw new Error('Function not implemented.');
}

