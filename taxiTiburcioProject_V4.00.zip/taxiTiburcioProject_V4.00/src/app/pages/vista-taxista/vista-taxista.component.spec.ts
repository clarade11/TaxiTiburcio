import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VistaTaxistaComponent } from './vista-taxista.component';

describe('VistaTaxistaComponent', () => {
  let component: VistaTaxistaComponent;
  let fixture: ComponentFixture<VistaTaxistaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VistaTaxistaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VistaTaxistaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
