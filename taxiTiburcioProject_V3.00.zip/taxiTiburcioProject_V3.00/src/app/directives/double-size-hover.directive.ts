import { Directive,ElementRef, HostListener  } from '@angular/core';

@Directive({
  selector: '[appDoubleSizeHover]'
})
export class DoubleSizeHoverDirective {

  constructor(   
    private elementRef:  ElementRef
    ) { }

  @HostListener('mouseover')
  onMouseOver(){
    this.elementRef.nativeElement.style.fontSize = '18px';
  }

  @HostListener('mouseout')
  onMouseOut(){
    this.elementRef.nativeElement.style.fontSize =  '16px';
  }

}
