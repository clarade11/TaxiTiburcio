import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HomeModel } from './home.model';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerFotos(){
    return this.http.get<HomeModel[]>(this.BASE_URL+'/home');
  }

  obtenerHomePorId(id: number){
    return this.http.get<HomeModel[]>(`${this.BASE_URL}/home/${id}`);
  }

  obtenerHomePorFoto(codigo: string){
    return this.http.get<HomeModel[]>(`${this.BASE_URL}/home/buscar/${codigo}`);
  }

  agregarFoto(home: HomeModel){
    return this.http.post<string>(`${this.BASE_URL}/home/agregar`,home);
  }

  actualizarHome(home: HomeModel){
    return this.http.put<string>(`${this.BASE_URL}/home/actualizar/${home.id}`,home);
  }

  borrarFoto(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/home/borrar/${id}`);
  }
}
