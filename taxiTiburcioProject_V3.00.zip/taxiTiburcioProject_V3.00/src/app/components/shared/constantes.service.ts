import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConstantesModel } from './constantes.model';

@Injectable({
  providedIn: 'root'
})
export class ConstantesService {


  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerConstantes(){
    return this.http.get<ConstantesModel[]>(this.BASE_URL+'/constantes');
  }

  obtenerConstantePorId(id: number){
    return this.http.get<ConstantesModel[]>(`${this.BASE_URL}/constantes/${id}`);
  }

  obtenerConstantePorCodigo(codigo: string){
    return this.http.get<ConstantesModel[]>(`${this.BASE_URL}/constantes/buscar/${codigo}`);
  }

  agregarConstante(constante: ConstantesModel){
    return this.http.post<string>(`${this.BASE_URL}/constantes/agregar`,constante);
  }

  actualizarConstante(constante: ConstantesModel){
    return this.http.put<string>(`${this.BASE_URL}/constantes/actualizar/${constante.id}`,constante);
  }

  borrarConstante(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/constantes/borrar/${id}`);
  }
}
