import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RutasModel } from './rutas.model';

@Injectable({
  providedIn: 'root'
})
export class RutasService {

  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerRutas(){
    return this.http.get<RutasModel[]>(this.BASE_URL+'/rutas');
  }

  obtenerRutaPorId(id: number){
    return this.http.get<RutasModel[]>(`${this.BASE_URL}/rutas/${id}`);
  }

  obtenerRutaPorDestino(destino: string){
    return this.http.get<RutasModel[]>(`${this.BASE_URL}/rutas/buscar/${destino}`);
  }

  agregarRuta(rutas: RutasModel){
    return this.http.post<string>(`${this.BASE_URL}/rutas/agregar`,rutas);
  }

  actualizarRuta(rutas: RutasModel){
    return this.http.put<string>(`${this.BASE_URL}/rutas/actualizar/${rutas.id}`,rutas);
  }

  borrarRuta(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/rutas/borrar/${id}`);
  }
}
