export class AsksModel{
  constructor(
    public id: number,
    public ask: string,
    public answer:string,
    public vigente:string,
    public f_creacion:Date,
    public f_modifica:Date
  ){
  }
}
