import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AccesoModel } from './acceso.model';

@Injectable({
  providedIn: 'root'
})
export class AccesoService {

  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerAccesos(){
    return this.http.get<AccesoModel[]>(this.BASE_URL+'/acceso');
  }

  obtenerAcceso(id: number){
    return this.http.get<AccesoModel[]>(`${this.BASE_URL}/acceso/${id}`);
  }

  obtenerAccesoUsuarioPassword(user: string){
    return this.http.get<AccesoModel[]>(`${this.BASE_URL}/acceso/buscar/${user}`);
  }

  agregarAcceso(acceso: AccesoModel){
    return this.http.post<string>(`${this.BASE_URL}/acceso/agregar`,acceso);
  }

  actualizarAcceso(acceso: AccesoModel){
    return this.http.put<string>(`${this.BASE_URL}/acceso/actualizar/${acceso.id}`,acceso);
  }

  borrarAcceso(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/acceso/borrar/${id}`);
  }

}
