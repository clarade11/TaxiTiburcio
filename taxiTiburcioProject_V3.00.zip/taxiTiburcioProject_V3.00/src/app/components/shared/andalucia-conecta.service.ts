import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Andalucia_conectaModel } from './andalucia_conecta.model';

@Injectable({
  providedIn: 'root'
})
export class AndaluciaConectaService {

  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerInformacionesAndaluciaConecta(){
    return this.http.get<Andalucia_conectaModel[]>(this.BASE_URL+'/andalucia_conecta');
  }

  obtenerInformacionAndaluciaConecta(id: number){
    return this.http.get<Andalucia_conectaModel[]>(`${this.BASE_URL}/andalucia_conecta/${id}`);
  }

  obtenerInformacionAndaluciaConectaPorRecogida(ciudad_recogida: string){
    return this.http.get<Andalucia_conectaModel[]>(`${this.BASE_URL}/andalucia_conecta/buscar/${ciudad_recogida}`);
  }

  agregarInformacionAndaluciaConecta(andalucia: Andalucia_conectaModel){
    return this.http.post<string>(`${this.BASE_URL}/andalucia_conecta/agregar`,andalucia);
  }

  actualizarInformacionAndaluciaConecta(andalucia: Andalucia_conectaModel){
    return this.http.put<string>(`${this.BASE_URL}/andalucia_conecta/actualizar/${andalucia.id}`,andalucia);
  }

  borrarInformacionAndaluciaConecta(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/andalucia_conecta/borrar/${id}`);
  }
}
