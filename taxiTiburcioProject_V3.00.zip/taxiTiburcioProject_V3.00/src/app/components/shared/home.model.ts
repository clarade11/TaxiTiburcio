export class HomeModel{
  constructor(
    public id: number,
    public photo: string,
    public description:string,
    public vigente:string,
    public f_creacion:Date,
    public f_modifica:Date
  ){
  }
}
