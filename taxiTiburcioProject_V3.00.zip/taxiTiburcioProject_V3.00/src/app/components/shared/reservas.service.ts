import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReservasModel } from './reservas.model';

@Injectable({
  providedIn: 'root'
})
export class ReservasService {

  BASE_URL = 'http://localhost:3000'

  constructor(private http: HttpClient){}

  // Otras funciones para crear, actualizar y eliminar elementos

  obtenerReservas(){
    return this.http.get<ReservasModel[]>(this.BASE_URL+'/reservas');
  }

  obtenerReservaPorId(id: number){
    return this.http.get<ReservasModel[]>(`${this.BASE_URL}/reservas/${id}`);
  }

  obtenerReservaPorTelefono(telefono: string){
    return this.http.get<ReservasModel[]>(`${this.BASE_URL}/reservas/buscar/${telefono}`);
  }

  agregarReserva(reserva: ReservasModel){
    return this.http.post<string>(`${this.BASE_URL}/reservas/agregar`,reserva);
  }

  actualizarReserva(reserva: ReservasModel){
    return this.http.put<string>(`${this.BASE_URL}/reservas/actualizar/${reserva.id}`,reserva);
  }

  borrarReserva(id: number){
    return this.http.delete<string>(`${this.BASE_URL}/reservas/borrar/${id}`);
  }
}
