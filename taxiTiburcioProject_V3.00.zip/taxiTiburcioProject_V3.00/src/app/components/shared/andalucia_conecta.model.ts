import { DecimalPipe } from "@angular/common";

export class Andalucia_conectaModel{
  constructor(
    public id: number,
    public ciudad_recogida: string,
    public hora_salida:string,
    public telefono_informacion:number,
    public precio:DecimalPipe,
    public num_plazas:number,
    public vigente:string,
    public f_creacion:Date,
    public f_modifica:Date
  ){
  }
}
