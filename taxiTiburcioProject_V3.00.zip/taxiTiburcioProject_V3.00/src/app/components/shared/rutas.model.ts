import { DecimalPipe } from "@angular/common";

export class RutasModel{
  constructor(
    public id: number,
    public imagen:string,
    public ciudad_recogida: string,
    public destino:string,
    public cod_postal:string,
    public calle_recogida:string,
    public precio:DecimalPipe,
    public vigente:string,
    public f_creacion:Date,
    public f_modifica:Date
  ){
  }
}
