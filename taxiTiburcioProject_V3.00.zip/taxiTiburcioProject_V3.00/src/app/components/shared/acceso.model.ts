export class AccesoModel{
  constructor(
    public id: number,
    public user: string,
    public password:string,
    public vigente:string,
    public f_creacion:Date,
    public f_modifica:Date
  ){
  }
}
