import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormularioReservaComponent } from './pages/formulario-reserva/formulario-reserva.component';
import { ApiWhatsappComponent } from './components/api-whatsapp/api-whatsapp.component';
import { HomeComponent } from './pages/home/home.component';
import { InformacionRutasComponent } from './pages/informacion-rutas/informacion-rutas.component';
import { ContactoComponent } from './pages/contacto/contacto.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { ConnectionBBDDComponent } from './components/connection-bbdd/connection-bbdd.component';
import { ErrorComponent } from './pages/error/error.component';
import { AccesTaxistaComponent } from './pages/acces-taxista/acces-taxista.component';
import { BlueHoverDirective } from './directives/blue-hover.directive';
import { DoubleSizeHoverDirective } from './directives/double-size-hover.directive';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { VistaTaxistaComponent } from './pages/vista-taxista/vista-taxista.component';
import { AccesoService } from './components/shared/accesoService.service';
import { AndaluciaConectaService } from './components/shared/andalucia-conecta.service';
import { HomeService } from './components/shared/home.service';
import { AsksService } from './components/shared/asks.service';
import { ConstantesService } from './components/shared/constantes.service';
import { ReservasService } from './components/shared/reservas.service';
import { RutasService } from './components/shared/rutas.service';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    FormularioReservaComponent,
    ApiWhatsappComponent,
    HomeComponent,
    InformacionRutasComponent,
    ContactoComponent,
    FooterComponent,
    HeaderComponent,
    ConnectionBBDDComponent,
    ErrorComponent,
    AccesTaxistaComponent,
    DoubleSizeHoverDirective,
    BlueHoverDirective,
    VistaTaxistaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatSnackBarModule,
    BrowserAnimationsModule
  ],
  providers: [
    AccesoService,
    AndaluciaConectaService,
    AsksService,
    ConstantesService,
    HomeService,
    ReservasService,
    RutasService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
