import { Component } from '@angular/core';
import { ReservasModel } from 'src/app/components/shared/reservas.model';
import { Observable } from 'rxjs';
import { ReservasService } from 'src/app/components/shared/reservas.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-formulario-reserva',
  templateUrl: './formulario-reserva.component.html',
  styleUrls: ['./formulario-reserva.component.scss']
})

export class FormularioReservaComponent {


  //creacion objeto
  public fechaActual = new Date();


  public reserva = {

    dia:this.fechaActual,
    hora_salida: this.fechaActual.getTime(),
    ciudad_recogida:'',
    cod_postal:0,
    nombre:'',
    nino:false,
    lugar_encuentro:'',
    num_personas:0,
    telefono:0,
    destino:''
  }

  //BBDD

  reservas: Observable<ReservasModel[]> | undefined


  constructor(private reservasService:ReservasService, private _snackBar: MatSnackBar){}

  ngOnInit(): void {

  }

  public reservar(dia:Date, hora_salida:number,ciudad_recogida:string,cod_postal:number,nombre:string,num_personas:number, nino:boolean,lugar_encuentro:string, telefono:number, destino:string ){

    const nuevaReserva: ReservasModel = {
      id:0, //al ser autoincremental en el back no se vuelca el 1
      telefono: this.reserva.telefono,
      nombre: this.reserva.nombre,
      ciudad_recogida: this.reserva.ciudad_recogida, // Deberías tener este valor disponible en el backend o en el formulario
      cod_postal: this.reserva.cod_postal, // Aquí puedes establecer un código postal si lo tienes disponible
      calle_recogida: this.reserva.lugar_encuentro, // Deberías tener este valor disponible en el backend o en el formulario
      fecha_viaje: this.reserva.dia,
      hora_viaje:this.reserva.hora_salida,
      sillita:'N',//pendiente traduccion a string el boolean
      num_personas: this.reserva.num_personas, // Puedes establecer un valor predeterminado o recogerlo del formulario
      finalizado: 'N', // Siempre establecido como 'N' según tu modelo
      f_modifica: new Date()
    };

    this.reservasService.agregarReserva(nuevaReserva).subscribe(() => {
      // Manejar la respuesta si es necesario
      console.log('Reserva agregada correctamente');
      this.mostrarMensaje('Reserva agregada correctamente');
    }, error => {
      console.error('Error al agregar reserva:', error);
    });

  }
  private mostrarMensaje(mensaje: string): void {
    this._snackBar.open(mensaje, 'Cerrar', {
      duration: 5000, // Duración del mensaje en milisegundos (5 segundos en este caso)
    });
  }
}
