import { Component } from '@angular/core';

@Component({
  selector: 'app-vista-taxista',
  templateUrl: './vista-taxista.component.html',
  styleUrls: ['./vista-taxista.component.scss']
})
export class VistaTaxistaComponent {

}
