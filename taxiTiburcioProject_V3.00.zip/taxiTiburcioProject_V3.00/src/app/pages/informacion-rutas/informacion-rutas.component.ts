import { Component , OnInit} from '@angular/core';
import { Observable } from 'rxjs';
import { RutasModel } from 'src/app/components/shared/rutas.model';
import { RutasService } from 'src/app/components/shared/rutas.service';


@Component({
  selector: 'app-informacion-rutas',
  templateUrl: './informacion-rutas.component.html',
  styleUrls: ['./informacion-rutas.component.scss']
})
export class InformacionRutasComponent {
// Definir la lista de rutas
//rutas = [
  //{ titulo: 'Lora del Río', imagen: '../../../assets/imagenesRutas/loraRio.jpg' },
  //{ titulo: 'Sevilla', imagen: '../../../assets/imagenesRutas/sevilla.jpg' },
  //{ titulo: 'Hospital Macarena', imagen: '../../../assets/imagenesRutas/sevilla_macarena.jpg' },
  //{ titulo: 'Hospital Virgen del Rocío', imagen: '../../../assets/imagenesRutas/hospital_virgen_rocio.jpg' }
//];

//BBDD
rutas: Observable<RutasModel[]> | undefined

constructor(private rutasService:RutasService){}

ngOnInit(): void {
  this.rutas = this.rutasService.obtenerRutas();
}

public ruta = {
  destino:'',
  imagen:''
}

}
