import { Component } from '@angular/core';

@Component({
  selector: 'app-api-whatsapp',
  templateUrl: './api-whatsapp.component.html',
  styleUrls: ['./api-whatsapp.component.scss']
})
export class ApiWhatsappComponent {

}
