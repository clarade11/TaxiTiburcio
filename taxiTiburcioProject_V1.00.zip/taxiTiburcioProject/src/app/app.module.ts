import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormularioReservaComponent } from './pages/formulario-reserva/formulario-reserva.component';
import { ApiWhatsappComponent } from './components/api-whatsapp/api-whatsapp.component';
import { HomeComponent } from './pages/home/home.component';
import { InformacionRutasComponent } from './pages/informacion-rutas/informacion-rutas.component';
import { ContactoComponent } from './pages/contacto/contacto.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { ConnectionBBDDComponent } from './components/connection-bbdd/connection-bbdd.component';

@NgModule({
  declarations: [
    AppComponent,
    FormularioReservaComponent,
    ApiWhatsappComponent,
    HomeComponent,
    InformacionRutasComponent,
    ContactoComponent,
    FooterComponent,
    HeaderComponent,
    ConnectionBBDDComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
